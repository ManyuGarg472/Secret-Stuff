import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from scripts import GazeboRosPaths

def generate_launch_description():
    urdf = '/home/manyu/ros2_ws/src/mini/urdf/mini.urdf'
    model_path, plugin_path, media_path = GazeboRosPaths.get_paths()
    env = {
        "GAZEBO_MODEL_PATH": model_path, # as we only to add maze_bot(model) into gazebo models path
        "GAZEBO_PLUGIN_PATH": plugin_path,
        "GAZEBO_RESOURCE_PATH": media_path,
    }
    return LaunchDescription(
        [
            Node(
                package= 'robot_state_publisher',
                executable= 'robot_state_publisher',
                name= 'robot_state_publisher',
                output= 'screen',
                arguments=[urdf]
            ),
            Node(
                package= 'joint_state_publisher',
                executable= 'joint_state_publisher',
                name= 'joint_state_publisher',
                output= 'screen',
            ),
            ExecuteProcess(
                cmd=["gazebo","-s","libgazebo_ros_factory.so",],
                output="screen",
                #additional_env=env,
            ),
            Node(
                package="gazebo_ros",
                executable="spawn_entity.py",
                name= 'urdf_spawner',
                output= 'screen',
                arguments=["-topic","/robot_description", "-entity", "mini", "-b"],
            ),
        ]
    )