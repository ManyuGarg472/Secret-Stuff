import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class PubPub(Node):
    def __init__(self):
        super().__init__('pubpub')
        self.publisher_ = self.create_publisher(String, 'RoboManipal', 10)
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info("Publishing")
        self.i = 0

    def timer_callback(self):
        msg = String()
        msg.data = "World Cup in 49 days"
        self.publisher_.publish(msg)
        self.i += 1

def main(args=None):
    rclpy.init(args=args)
    pubpub = PubPub()
    rclpy.spin(pubpub)
    rclpy.shutdown

if __name__ == '__main__':
    main()